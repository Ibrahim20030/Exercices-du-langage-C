#include <stdio.h>
#include <stdlib.h>


char *inverse(char *p){
    char *n;
    int i,j;
    n = (char*)malloc(strlen(p)*sizeof(char));
    for(i=strlen(p), j=0; i>0, j<strlen(p); i--, j++) *(n+j) = *(p+i-1);
        *(n+strlen(p))='\0';
    return n;
}

int main()
{
    char *a, *b;
    a = (char*)malloc(30*sizeof(char));
    printf("Donner un nom: ");
    gets(a);
    b = inverse(a);
    if(*a==*b) printf("Le mot saisis est palindrome");
    else printf("Le mot saisis n'est pas palindroma");
    return 0;
}
