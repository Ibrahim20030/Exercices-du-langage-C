#include <stdio.h>
#include <stdlib.h>

int main()
{
    float Prix1, Prix2, Remise;
    printf("Donner le prix initial du produit: ");
    scanf("%f",&Prix1);

    if(Prix1<100){
    Remise = (30*Prix1)/100;
    }

    if(Prix1>=100 && Prix1<=200){
    Remise = (40*Prix1)/100;
    }

    if(Prix1>200){
    Remise = (50*Prix1)/100;
    }

    Prix2 = Prix1 - Remise;
    printf(" Prix Initial: %.2f DH\n Remise: %.2f DH\n Prix Final: %.2f DH",Prix1,Remise,Prix2);
    return 0;
}
