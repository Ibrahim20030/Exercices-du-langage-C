#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,cmp,i;
    printf("Donner un nombre: ");
    scanf("%d",&n);
    cmp=0;
    for(i=1;i<=n/2;i++){
    if(n%i==0){
    cmp++;
    }
    }
    if(cmp==1){
    printf("le nombre %d est premier",n);
    }
    else{
    printf("le nombre %d n'est pas premier",n);
    }
    return 0;
}
