#include <stdio.h>
#include <stdlib.h>
#include<string.h>
void crypte(char *cMsg){
    int i;
    for(i=0; i<strlen(cMsg); i++)
        if( (cMsg[i]>=65 && cMsg[i]<=90) || (cMsg[i]>=97 && cMsg[i]<=122) ) cMsg[i]+=5;
    puts(cMsg);
}
void Decrypte(char *cMsg){
    int i;
    for(i=0; i<strlen(cMsg); i++)
        if( (cMsg[i]>=65 && cMsg[i]<=90) || (cMsg[i]>=97 && cMsg[i]<=122) ) cMsg[i]-=5;
    puts(cMsg);
}

int main()
{
    char C[20];
    char choix;
    do{
        printf("Donner la chaine de caractere a crypter: ");
        scanf(" %s",C);
        printf("Votre chaine de caractere avant le cryptage est: %s\n",C);
        printf("Votre chaine de caractere apres le cryptage est: ");
        crypte(C);
        printf("Voulez-vous continuer:\nO: Oui\t N: Non\tA:decrypte \n ");
        scanf(" %c",&choix);

        if(choix==65){
            printf("Donner la chaine de caractere a decrypter: ");
            scanf(" %s",C);
            printf("Votre chaine de caractere apres le decryptage est: ");
            Decrypte(C);
            printf("Voulez-vous continuer:\nO: Oui\t N: Non\tA:decrypte \n ");
            scanf(" %c",&choix);
        }

    }while(choix==79);
    return 0;
}
