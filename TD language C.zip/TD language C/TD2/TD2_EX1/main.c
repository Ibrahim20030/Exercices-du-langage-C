#include <stdio.h>
#include <stdlib.h>

#define Nmax 20
int T[Nmax];
float Moy;
int NE, i, S;
int pos_ajout, NA, min, pos_min, max, pos_max, cmp=0;
char choix=0;

void saisie(){
    do{
        printf("Donner le nombre d'elements (<=20): ");
        scanf("%d",&NE);
    }while(NE>20);
    for(i=0;i<NE;i++){
        printf("T[%d] = ",i);
        scanf("%d",&T[i]);
    }
}
void Affichage(){
    printf("\nLes elements du tableau sont:\n");
    for(i=0;i<NE;i++){
        printf("%d\n",T[i]);
    }
}

void Moyenne(){
    S=0;
    for(i=0;i<NE;i++){
        S = S + T[i];
    }
    Moy = (float)S/NE;
    printf("\nLa moyenne du tableau est: %.2f\n",Moy);
}

int Max_elem(){
    max=T[0];
    for(i=0;i<NE;i++)
        if(T[i]>max){
        max = T[i];
        pos_max = i;
        }
    return pos_max;
}
void Supprime_max(){
    int n=Max_elem();
    for(i=n;i<NE;i++) T[i]=T[i+1];
        NE--;
}

int Min_elem(){
    min=T[0];
    for(i=0;i<NE;i++)
        if(T[i]<min){
        min = T[i];
        pos_min = i;
        }
    return pos_min;
}
void Supprime_min(){
    int n=Min_elem();
    for(i=n;i<NE;i++) T[i]=T[i+1];
    NE--;
}

void Ajout(){
    do{
        printf("Donner la position: ");
        scanf("%d",&pos_ajout);
    }while(pos_ajout>NE || pos_ajout<0);
    printf("Saisir le nombre a ajouter: ");
    scanf("%d",&NA);
    NE++;
    for(i=NE;i>=pos_ajout;i--){
        T[i+1]=T[i];
    }
    T[pos_ajout] = NA;
}

int main(){
    while(choix!=81 && choix!=113){ //Code ascii du lettre Q est 81
        printf("\nMenu : \n A-Saisie et affichage\n B-Moyenne\n C-Suppression du Max etaffichage\n D-Suppression du Min et affichage\n E-Ajout d'un entier a une position\n Q-Quitter\n");
        printf("Choisir: ");
        scanf(" %c",&choix);
        switch(choix){
            case'A':
                saisie();
                Affichage();
                break;
            case'B':
                Moyenne();
                break;
            case'C':
                Supprime_max();
                Affichage();
                break;
            case'D':
                Supprime_min();
                Affichage();
                break;
            case'E':
                Ajout();
                Affichage();
                break;
            default:
                break;
        }
    }
    return 0;
}
