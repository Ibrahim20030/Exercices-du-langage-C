#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main(){

    //question 1
    int N,i;
    for(i=1;i<=20;i++){
        printf("donner le nombre numero %d: ",i);
        scanf("%d",&N);
        if(N%2==0){
        printf("Le carre de %d est %d\n",N,N*N);
        }
    }
    //question 2
    printf("\nQuestion 2\n");
    int N_E=0,N_E_P=0;

    while(N!=100){
        printf("Donner un nombre: ");
        scanf("%d",&N);
        N_E++;
        if(N%2==0){
        printf("Le carre de %d est %d\n",N,N*N);
        N_E_P++;
        }
    }
    printf("Le nombre total d'entrees est: %d\n",N_E);
    printf("Le nombre d'entrees paires est: %d",N_E_P);
    return 0;
}
