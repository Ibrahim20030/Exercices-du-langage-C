#include <stdio.h>
#include <stdlib.h>
int i,j;
float Somme_form_usuel(float A[3][4], int li, int col){
    float Som=0;
    for(i=0; i<li; i++)
        for(j=0; j<col; j++) Som += A[i][j];
    return Som;
}
float Somme_form_poin(float **A, int li, int col){
    float Som=0;
    for(i=0; i<li; i++)
        for(j=0; j<col; j++) Som += *(*(A+i)+j);
        return Som;
}
int main()
{
    float t[3][4];
    float somme;
    float **C;

    C = (float**)malloc(3*sizeof(float*));
    for(i=0; i<4; i++)
        *(C+i) = (float*)malloc(4*sizeof(float));

    for(i=0; i<3; i++)
        for(j=0; j<4; j++){
            printf("t[%d][%d] = ",i,j);
            scanf("%f",&t[i][j]);
        }

    for(i=0; i<3; i++)
        for(j=0; j<4; j++)
            *(C+j) = *(t+i);

    for(i=0; i<3; i++){
        for(j=0; j<4; j++) printf("%.2f \t",*(*(t+i)+j));
        printf("\n");
    }

    somme = Somme_form_usuel(t,3,4);
    printf("\nEn utilisant le formalisme usuel des tabeaux: \nLa somme des elements du tableau est: %.2f \n",somme);

    somme = Somme_form_poin(C,3,4);
    printf("\nEn utilisant le formalisme de pointeurs: \nLa somme des elements du tableau est: %.2f \n",somme);
    return 0;
}
