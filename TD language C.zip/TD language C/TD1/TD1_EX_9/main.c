#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, cmp=0, S=0, SP=0, min=9999, minPo=9999;

    while(n != 999){
    printf("Donner un nombre: ");
    scanf("%d",&n);
    if(n==999) break;
    else{
    cmp++;
    S = S + n;
    if(n < min)
    min=n;
    if(n>0)
    SP = SP + n;
    if(n>0 && n < minPo)
    minPo=n;
    }
    };
    printf("Le nombre total de valeurs de la suite: %d\n",cmp);
    printf("La somme des valeurs lues: %d\n",S);
    printf("Le minimum: %d\n",min);
    printf("La somme des valeurs strictement positives: %d\n",SP);
    printf("Le minimum des valeurs strictement positives: %d\n",minPo);

    return 0;
}
