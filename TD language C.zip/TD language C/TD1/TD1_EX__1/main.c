#include <stdio.h>
#include <stdlib.h>

int main()
{   int a,b;
    char c;

    printf("Choisir un  operateur :");
    scanf("%c",&c);
    printf("donner a :");
    scanf("%d",&a);
    printf("donner b :");
    scanf("%d",&b);
    switch(c){
        case '+':printf("a+b=%d \n",a+b);
        break;
        case '-':printf("a-b=%d \n",a-b);
        break;
        case '*':printf("a*b=%d \n",a*b);
        break;
        case '/':printf("a/b=%d \n",a/b);
        break;
    }
    return 0;
}
