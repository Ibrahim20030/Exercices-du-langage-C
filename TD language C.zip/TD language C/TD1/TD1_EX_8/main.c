#include <stdio.h>
#include <stdlib.h>

int main()
{
    //question a
    int i,j,A,B;
    printf("donner le prmier  nombre :");
    scanf("%d",&A);
    printf("donner le deuxeme nombre :");
    scanf("%d",&B);

    for(j=A;j>=1;j--){
        for(i=j;i>=1;i--){
            printf("%d",i);
        }
        printf("\n");
    }

    //question b
    int k;

    printf("\n");
    for(i=0;i<B;i++){
        for(j=0;j<i;j++){
            printf(" ");
        }
        for(k=B;k>i;k--){
        printf("%d",i);
        }
        printf("\n");
    }
    return 0;
}
