#include <stdio.h>
#include <stdlib.h>

int main()
{
    int N,i;
    printf("Donner un nombre pair: ");
    scanf("%d",&N);
    if(N%2==0){
    printf("les nombres pairs qui lui sont inferieur sont: \n");
    for(i=2;i<=N;i++){
    if(i%2==0) printf("%d \n",i);
    }
    }
    return 0;
}
