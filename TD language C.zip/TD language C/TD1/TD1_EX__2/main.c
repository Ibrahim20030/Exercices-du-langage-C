#include <stdio.h>
#include <stdlib.h>

int main(){
    int age;
    char sexe;
    printf("Donner votre age: ");
    scanf("%d",&age);
    printf("Donner votre sexe (H OU F ):");
    scanf(" %c",&sexe);

    if( (sexe=='H' && age>=20) || (sexe=='F' && (age>=18 && age<=35)) ){
        printf("Vous etes imposable");
    }
    else{
    printf("Vous n'etes pas imposable");
    }

    return 0;
    }

