#include <stdio.h>
#include <stdlib.h>

int nbr_occ(char *ph, char *mot){
    int resultat;
    char *p=ph;
    while( (p=strstr(p,mot)) != NULL){
        resultat++;
        p += strlen(mot);
    }
    return resultat;
}
int main()
{
    char *ph, *mot;
    int resultat;
    ph = (char*)malloc(250*sizeof(char));
    mot = (char*)malloc(15*sizeof(char));
    printf("Donner une phrase: ");
    gets(ph);
    printf("Donner un mot: ");
    gets(mot);
    resultat = nbr_occ(ph,mot);
    printf("\nLe nombre d'occurence de (%s) dans la phrase est: %d",mot,resultat);
    return 0;
}
