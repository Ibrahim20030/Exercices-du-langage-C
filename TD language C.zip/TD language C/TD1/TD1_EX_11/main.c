#include <stdio.h>
#include <stdlib.h>

int main()
{
    int N=0,choix;
    printf("Donner un entier: ");
    scanf("%d",&N);
    printf("La valeur de l'entier est: %d\n",N);
    do{
        printf("\n 1.Ajouter 2\n 2.Multiplier par 3\n 3.Soustraire 5\n 4.Quitter\nChoisir entre 1 et 4: ");
        scanf("%d",&choix);
        switch(choix){
            case 1:
            printf("La nouvelle valeur est: %d\n",N+2);
            break;
            case 2:
            printf("La nouvelle valeur est: %d\n\n",N*3);
            break;
            case 3:
            printf("La nouvelle valeur esr: %d\n\n",N-5);
            break;
            case 4:
            break;
        }
    }while(choix < 4);
    return 0;
}
