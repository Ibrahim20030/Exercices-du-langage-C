#include <stdio.h>
#include <stdlib.h>

int i,j;
void Saisie_matrice(int iMat[5][5]){
    for(i=0; i<5; i++){
        for(j=0; j<5; j++){
            printf("iMat[%d][%d] = ",i,j);
            scanf("%d",&iMat[i][j]);
        }
    }
}
void Afficher_matrice(int iMat[5][5]){
    printf("__________");
    for(i=1; i<5; i++){
        printf("\n");
        for(j=1; j<5; j++)
            printf("|%d",iMat[i][j]);
        printf("|");
        printf("\n__________");
    }
}
int main()
{
    int iMat[5][5];
    Saisie_matrice(iMat);
    Afficher_matrice(iMat);
    return 0;
}
