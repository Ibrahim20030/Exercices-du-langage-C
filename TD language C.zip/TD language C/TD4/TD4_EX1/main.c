#include <stdio.h>
#include <stdlib.h>

typedef struct Complexe{
    int reel;
    int img;
}Complexe;

double imag(Complexe z){
    return z.img;
}
double reel(Complexe z){
    return z.reel;
}
Complexe mul(Complexe z1, Complexe z2){
    Complexe pro;
    pro.reel = ( reel(z1)*reel(z2) - imag(z1)*imag(z2) );
    pro.img = ( reel(z1)*imag(z2) + imag(z1)*reel(z2) );
    return pro;
}
int main()
{
    Complexe z1, z2, w;
    printf("Donner la partie real de z1: ");
    scanf("%d",&z1.reel);
    printf("Donner la partie imaginaire de z1: ");
    scanf("%d",&z1.img);
    printf("Donner la partie real de z2: ");
    scanf("%d",&z2.reel);
    printf("Donner la partie imaginaire de z2: ");
    scanf("%d",&z2.img);
    printf("z1 = %.2lf + %.2lf i\n", reel(z1), imag(z1) );
    printf("z2 = %.2lf + %.2lf i\n", reel(z2), imag(z2) );
    w = mul(z1,z2);
    printf("z1 x z2 = %.2lf + %.2lf i", reel(w), imag(w));
    return 0;
}
