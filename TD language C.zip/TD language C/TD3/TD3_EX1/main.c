#include <stdio.h>
#include <stdlib.h>
#include<string.h>

int main()
{
    char *nom, *de, *fi;
    char temp;
    int n;
    nom = (char*)malloc(30*sizeof(char));
    printf("Donner un nom: ");
    gets(nom);
    n = strlen(nom);
    de = nom;
    fi = nom+n-1;
    while( de <= fi ){
        temp = *de;
        *de = *fi;
        *fi = temp;
        de++;
        fi--;
    }
    printf("Votre nom inverse est: %s",nom);
    return 0;
}
