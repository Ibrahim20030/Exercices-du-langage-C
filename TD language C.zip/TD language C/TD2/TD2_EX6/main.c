#include <stdio.h>
#include <stdlib.h>
#include<string.h>
int main()
{
    const int Max=100;
    int i;
    int cmpEsp, cmpChif, cmpAut;
    char T[Max];
    cmpEsp = cmpChif = cmpAut = 0;
    printf("Sasir un chaine de caractere: ");
    gets(T);

    for(i=0;i<strlen(T);i++){
        if(T[i] ==' ' || T[i] =='\n' || T[i] =='\t') cmpEsp++;
        else if((T[i] >=65 && T[i] <=90) || (T[i] >=97 && T[i] <=122) ) cmpChif++;
        else cmpAut++;
    }
    printf("Nombres des espaces, des tabulations et des retours a la ligne est: %d\n",cmpEsp);
    printf("Nombres des chiffres est: %d\n",cmpChif);
    printf("Nombres des autres caracteres est: %d",cmpAut);
    return 0;
}
