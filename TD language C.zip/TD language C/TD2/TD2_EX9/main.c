#include <stdio.h>
#include <stdlib.h>
#include<string.h>

void menu(){
    printf("\n          **************** MENU ******************\n");
    printf("            Choisir votre operation : \n");
    printf("            1. Saisir. \n            2. Afficher. \n            3. Inverser. \n            4. Compte les mots.\n            5. Quitter. \n");
    printf("\n          ****************************************\n");
}
char* saisir(){
    char *T = (char*)malloc(50*sizeof(char));
    printf("\nDonnez la chaine : ");
    getchar();
    gets(T);
    return T;
}
void affiche(char* s){
    printf("votre chaine est : %s \n",s);
}
void inverser(char *T){
    int i,j;
    char T2[strlen(T)];
    strcpy(T2,T);
    for(i=0;i<strlen(T);i++){
        T[i] = T2[strlen(T)-i-1];
    }
    printf("L'inverse de votre chaine est : %s",T);
}
void mots(char *T){
    int i,cmp=1;
    for(i=0;i<strlen(T);i++){
        if(T[i] ==' ' || T[i] =='\t' || T[i] =='\n'){
            cmp++;
        }
    }
    printf("Le nombre de mots  dans votre chaine est : %d",cmp);
}
int main()
{
    char *T;
    int choix;
    do{
        menu();
        printf("Votre choix : ");
        scanf("%d",&choix);
        printf("\n========================================\n");
        if(choix == 1){
            T = saisir();
        }
        else if(choix == 2){
            affiche(T);
        }
        else if(choix == 3){
            inverser(T);
        }
        else if(choix == 4){
            mots(T);
        }
    }while(choix != 5);
    return 0;
}
