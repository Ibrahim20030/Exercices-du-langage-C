#include <stdio.h>
#include <stdlib.h>

int main(){

    int NP;
    float Prix;

    printf("Donner le nombre de photocopie: ");
    scanf("%d",&NP);

    if(NP <= 10){
        Prix=NP;
        printf("facture=%.2f DH ",Prix);
    }
    else if(NP >10 && NP <=30){
        Prix = 10 + 0.6*(NP - 10);
        printf("facture=%.2f DH ",Prix);
    }
    else {
        Prix = 10 + 0.6*20 + 0.4*(NP - 30);
        printf("facture=%.2f DH ",Prix);
    }

    return 0;
    }
