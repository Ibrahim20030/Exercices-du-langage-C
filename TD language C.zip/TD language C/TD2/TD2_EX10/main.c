#include <stdio.h>
#include <stdlib.h>
#include<string.h>

int distanceH(char* s1,char* s2){
    int i,n=0;
    for(i=0;i<strlen(s1);i++){
        if(s1[i] != s2[i]){
        n++;
        }
    }
    return n;
}
int distanceH_langage(char** langage,int t){
    int i,min=50,tmp;
    for(i=0;i<t-1;i++){
        tmp = distanceH(langage[i],langage[i+1]);
        if(min>tmp) min = tmp;
    }
    return min;
}

void converte_binaire(int T[],int dec){
    for(int i=0;i<8;i++){
        T[7-i] = dec%2;
        dec = dec/2;
    }
}
int distanceH_numbers(int N1,int N2){
    int i,T1[8],T2[8],cmp=0;
    converte_binaire(T1,N1);
    converte_binaire(T2,N2);
    for(i=0;i<8;i++){
        if(T1[i] != T2[i]){
            cmp++;
        }
    }
    return cmp;
}

int main()
{
    char S1[50],S2[50];
    char *lang[10];
    int taille,i,n1,n2;
    for(int i = 0 ; i < 10 ; i++){
        lang[i] = (char *)malloc(50);
    }
    //Question 1:
    do{
        printf("Donnez S1 : ");
        gets(S1);
        printf("Donnez S2 : ");
        gets(S2);
    }while(strlen(S1) != strlen(S2));
    printf("La distance de Hamming entre '%s' et '%s' est : %d",S1,S2,distanceH(S1,S2));
    //Question 2:
    printf("\n\nDonnez le nombre de mots : ");
    scanf("%d",&taille);
    printf("Donnez le langage : \n");
    for(i=0;i<taille;i++){
        printf("mot %d : ",i+1);
        scanf("%s",lang[i]);
    }
    printf("La distance de Hamming de langage est : %d",distanceH_langage(lang,taille));
    //Question 3:
    printf("\n\nDonnez nombre 1 : ");
    scanf("%d",&n1);
    printf("Donnez nombre 2 : ");
    scanf("%d",&n2);
    printf("La distance de Hamming entre les nombres %d et %d est :%d",n1,n2,distanceH_numbers(n1,n2));
    return 0;
}
