#include <stdio.h>
#include <stdlib.h>
#include<string.h>

int Addition(int A, int B){
    return A+B;
}

int Soustraction(int A, int B){
    return A-B;
}

int Multiplication(int A, int B){
    return A*B;
}
int Division(int A, int B){
    return A/B;
}
int Modulo(int A, int B){
    return A%B;
}
int main()
{
    char C[50];
    char Ope,choix;
    int i,nbr1,nbr2;
    do{
        printf("Donner une operation: ");
        scanf("%d %c %d",&nbr1,&Ope,&nbr2);

        switch(Ope){
            case'+':
                printf("%d %c %d = %d",nbr1,Ope,nbr2,Addition(nbr1,nbr2));
                break;
            case'-':
                printf("%d %c %d = %d",nbr1,Ope,nbr2,Soustraction(nbr1,nbr2));
                break;
            case'*':
                printf("%d %c %d = %d",nbr1,Ope,nbr2,Multiplication(nbr1,nbr2));
                break;
            case'/':
                printf("%d %c %d = %d",nbr1,Ope,nbr2,Division(nbr1,nbr2));
                break;
            case'%':
                printf("%d %c %d = %d",nbr1,Ope,nbr2,Modulo(nbr1,nbr2));
                break;
            default:
                printf("Erreur");
                break;
            }
        printf("\n Voulez vous continuer:\n O: Oui \t N: Non --> ");
        scanf(" %c",&choix);
    }while(choix!='N'&& choix=='O');
    return 0;
}
