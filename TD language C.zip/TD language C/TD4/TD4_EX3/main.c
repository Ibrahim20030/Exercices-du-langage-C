#include <stdio.h>
#include <stdlib.h>
#include<string.h>
typedef struct etudiant{
    char nom[15], prenom[15];
    int CNE;
    float notes[4], moyenne;
}etudiant;
int main()
{
    int n, i, j;
    float S, moy, NOTES[4];
    int cne;
    char NOM[15], PRENOM[15];
    printf("Donner le nombre des etudiants: ");
    scanf("%d",&n);
    etudiant T[n];
    // Lecture des informations des etudiants
    printf("\n\n");
    printf("Veuillez saisir les informations des etudiants: \n");
    for(i=0; i<n; i++){
        S = 0;
        printf("<------ Etudiant %d ------> \n",i+1);
        printf("Nom: ");
        scanf(" %s",T[i].nom);
        printf("Prenom: ");
        scanf(" %s",T[i].prenom);
        printf("CNE: ");
        scanf("%d",&T[i].CNE);
        for(j=0; j<4; j++){
            printf("Note[%d] = ",j+1);
            scanf("%f",T[i].notes[j]);
            S = S + T[i].notes[j];
        }
        T[i].moyenne = S / 4;
        printf("\n");
    }
    // Affichage des informations des etudiants
    printf("\n\n");
    printf("Les informations saisis sont: \n");
    for(i=0; i<n; i++){
        printf("<------ Etudiant %d ------>\n",i+1);
        printf("Nom: %s \n",T[i].nom);
        printf("Prenom: %s \n",T[i].prenom);
        printf("CNE: %d \n",T[i].CNE);
    for(j=0; j<4; j++) printf("Note[%d] = %.2f \n", j+1,T[i].notes[j]);
    printf("Moyenne = %.2f \n", T[i].moyenne);
    printf("\n");
    }
    // Recherche de la plus grande moyenne
    moy = T[0].moyenne;
    for(i=0; i<n; i++){
        if( T[i].moyenne > moy ){
            for(j=0; j<15; j++){
                NOM[j] = T[i].nom[j];
                PRENOM[j] = T[i].prenom[j];
            }
            cne = T[i].CNE;
            for(j=0; j<4; j++) NOTES[j] = T[i].notes[j];
            moy = T[i].moyenne;
        }
    }
    // Affichage des informations de l'etudiant ayant la plus grande moyenne
    printf("\n\n");
    printf("L'etudiant ayant la plus grand moyenne est %s, ces informations sont: \n", NOM);
    printf("Nom: %s \n",NOM);
    printf("Prenom: %s \n",PRENOM);
    printf("CNE: %d \n",cne);
    for(i=0; i<4; i++) printf("Note[%d] = %.2f \n",i+1,NOTES[i]);
    printf("Moyenne = %.2f \n", moy);
    // Trie du Tableau selon la moyenne
    for(i=0; i<n; i++)
        for(j=i; j<n; j++)
            if(T[j].moyenne > T[i].moyenne ){
                T[i].moyenne = T[i].moyenne +
                T[j].moyenne;
                T[j].moyenne = T[i].moyenne -
                T[j].moyenne;
                T[i].moyenne = T[i].moyenne -
                T[j].moyenne;
            }
    return 0;
}
