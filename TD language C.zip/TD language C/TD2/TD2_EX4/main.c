#include <stdio.h>
#include <stdlib.h>

int longeur_chaine1(char T[50]){
    int longeur=0,i=0;
    while(T[i]!='\0'){
        longeur++;
        i++;
    }
    return(longeur);
}

int main()
{   int L1, L2;
    char cTab1[]="ABCDEFGH";
    char cTab2[]="abc";
    L1=longeur_chaine1(cTab1);
    printf("La longuer de cTab1 est: %d\n",L1);
    L2=longeur_chaine1(cTab2);
    printf("La longuer de cTab2 est: %d",L2);
    return 0;
}
